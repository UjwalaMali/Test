console.log("hello")

fetch("https://jsonplaceholder.typicode.com/users")
.then((res)=>res.json())
.then((data)=>console.log(data));
const data={
    title:"this is title",
    body:"this is post body",
    userid:2
}
fetch("http://jsonplaceholder.typicodw.com/post",{
    method:"post",
    body:json.stringifly(data),
    headers:{"content type":"application/json"}

}
    )
    .then((res)=>res.json())
    .then((data)=>console.log(data));


